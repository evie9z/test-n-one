# Vendored-in for from google-apitools 0.4.11
